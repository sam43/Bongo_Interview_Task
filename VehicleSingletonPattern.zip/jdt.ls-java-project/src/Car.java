class Car {
    public int num_of_wheels;
    public int num_of_passengers;
    public boolean has_gas;

    public Car (int wheels, int passengers, boolean gas) {
      this.num_of_wheels = wheels;
      this.num_of_passengers = passengers;
      this.has_gas = gas;
    }
}