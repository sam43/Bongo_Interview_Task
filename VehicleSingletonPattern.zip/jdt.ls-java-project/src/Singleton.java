class Singleton {
  private static Singleton instance = null;

  Singleton() {}

  public static Singleton getInstance(){
        if(instance == null){
            instance = new Singleton();
        }
        return instance;
    }

  public void printLine(String str) {
    System.out.println(str);
  }

  public Car createAndGetCar(int wheels, int passengers, boolean gas) {
    return new Car(wheels, passengers, gas);
  }

  public Plane createAndGetPlane(int wheels, int passengers, boolean gas) {
    return new Plane(wheels, passengers, gas);
  }

}