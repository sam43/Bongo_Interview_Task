class Plane {
    private int num_of_wheels;
    private int num_of_passengers;
    private boolean has_gas;

    public Plane (int wheels, int passengers, boolean gas) {
      this.num_of_wheels = wheels;
      this.num_of_passengers = passengers;
      this.has_gas = gas;
    }

    public int getNumberOfWheels() { return num_of_wheels; }
    
    public int getNumberOfPassengers() { return num_of_passengers; }
    
    public boolean doesHaveGas() { return has_gas; }
}