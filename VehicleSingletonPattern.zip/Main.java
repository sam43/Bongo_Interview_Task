class Main {
  public static void main(String[] args) {
    Singleton instance = Singleton.getInstance();
    Car car = instance.createAndGetCar(4,4,true);
    Plane plane = instance.createAndGetPlane(3,189,false);
    //Singleton c = Singleton.getInstance();
    //c.printLine("printing from singleton class");

    //Car config
    System.out.println("\n\nCar config: \nWheels = "+car.num_of_wheels+"\nNo. of Passenger = "+car.num_of_passengers+"\nHas gas?"+car.has_gas+"\n\n");

    //Plane config
    System.out.println("\nPlane config: \nWheels = "+plane.getNumberOfWheels()+"\nNo. of Passenger = "+plane.getNumberOfPassengers()+"\nHas gas?"+plane.doesHaveGas()+"\n\n");
  }
}