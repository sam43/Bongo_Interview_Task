class Main {
  public static void main(String[] args) {
    Car car = new Car(4,4,true);
    Plane plane = new Plane(3,189,false);
    // Let's build a car
    System.out.println("\nFor Car : \nWheels = "+car.getNumberOfWheels()+"\nPassengers = "+car.getNumberOfPassengers()+"\nDoes it has gas? = "+car.hasGas()+"\n\n");
    // Build a plane now
    System.out.println("For Plane : \nWheels = "+plane.getNumberOfWheels()+"\nPassengers = "+plane.getNumberOfPassengers()+"\nDoes it has gas? = "+plane.hasGas());
  }
}