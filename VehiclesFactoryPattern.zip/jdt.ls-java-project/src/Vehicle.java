abstract class Vehicle {
  abstract int getNumberOfWheels();
  abstract int getNumberOfPassengers();
  abstract boolean hasGas();
}