class Plane extends Vehicle {

  private int num_of_wheels;
  private int num_of_passengers;
  private boolean has_gas;

  public Plane (int wheels, int passengers, boolean gas) {
    this.num_of_wheels = wheels;
    this.num_of_passengers = passengers;
    this.has_gas = gas;
  }

  @Override
	public int getNumberOfWheels() {
		return this.num_of_wheels;
	}

	@Override
	public int getNumberOfPassengers() {
		return this.num_of_passengers;
	}

	@Override
	public boolean hasGas() {
		return this.has_gas;
	}

}