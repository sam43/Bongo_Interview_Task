class Main {
  public static void main(String[] args) {
    // So let's build the Car
    Car car = new Car();
    car.buildCar();
    
    // let's build and config the plane now
    Plane plane = new Plane();
    plane.buildPlane();
  }
}