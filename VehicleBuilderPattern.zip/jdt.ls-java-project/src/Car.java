class Car {
    Vehicle car = new Vehicle.VehicleBuilder(4, 4, true).build();
  public void buildCar() {
    // So let's build the Car
    System.out.println("So, Car config is: No. of wheels = "+car.getNumberOfWheels() + "\nNo. of passengers = " + car.getNumberOfPassengers() + " and\nCar has gas in it ("+car.hasGas()+")\n\n");
  }
}