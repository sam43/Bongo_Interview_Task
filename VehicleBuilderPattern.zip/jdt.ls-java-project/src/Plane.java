class Plane {
    Vehicle plane = new Vehicle.VehicleBuilder(3, 189, false).build();
  public void buildPlane() {
    // let's build and config the plane now
    System.out.println("So, the Plane config is with: No. of wheels = "+plane.getNumberOfWheels() + "\nNo. of passengers = " + plane.getNumberOfPassengers() + " and\nPlane has gas? = "+plane.hasGas()+"; cause it's runs with Gasoline only.");
  }
}