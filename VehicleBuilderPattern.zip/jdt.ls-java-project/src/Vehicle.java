class Vehicle {

  public static class VehicleBuilder {
    private int numberOfWheels;
    private int numberOfPassengers;
    private boolean hasGas;

    public VehicleBuilder (
      int number_of_wheels,
      int number_of_passengers,
      boolean has_gas
    ) {
      this.numberOfWheels = number_of_wheels;
      this.numberOfPassengers = number_of_passengers;
      this.hasGas = has_gas;
    }
    
    public Vehicle build() {
      return new Vehicle(this);
    }

  }

  private int number_of_wheels;
  private int number_of_passengers;
  private boolean has_gas;

  public int getNumberOfWheels(){
    return number_of_wheels;
  }

  public int getNumberOfPassengers() {
    return number_of_passengers;
  }

  public boolean hasGas() {
    return has_gas;
  }

  private Vehicle(VehicleBuilder builder) {
    this.number_of_wheels = builder.numberOfWheels;
    this.number_of_passengers = builder.numberOfPassengers;
    this.has_gas = builder.hasGas;
  }
}