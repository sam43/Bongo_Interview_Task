import java.util.*;
import java.lang.*;
import java.io.*;
 
/* Name of the class has to be "Main" only if the class is public. */
class AnagramTesting
{
	static boolean isAnagram(String input, String output) {
    if (input.length() != output.length()) {
        return false;
    }
	    char[] a1 = input.toCharArray();
	    char[] a2 = output.toCharArray();
	    Arrays.sort(a1);
	    Arrays.sort(a2);
	    return Arrays.equals(a1, a2);
	}
 
	public static void main (String[] args) throws java.lang.Exception
	{
		if (isAnagram("table","latbe")) {
			System.out.println("Is anagram");
		} else {
			System.out.println("Not an anagram");
		}
	}
}